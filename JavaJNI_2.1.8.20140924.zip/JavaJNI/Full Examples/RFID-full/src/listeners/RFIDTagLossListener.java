/* - RFIDTagLossListener -
 * Here we simply want to clear our tag field in the GUI
 *
 * Copyright 2007 Phidgets Inc.  
 * This work is licensed under the Creative Commons Attribution 2.5 Canada License. 
 * To view a copy of this license, visit http://creativecommons.org/licenses/by/2.5/ca/
 */

package listeners;

import com.phidgets.event.TagLossListener;
import com.phidgets.event.TagLossEvent;

import javax.swing.JTextField;

public class RFIDTagLossListener implements TagLossListener{
    
    private JTextField tagTxt;
    
    /** Creates a new instance of RFIDTagLossListener */
    public RFIDTagLossListener(JTextField tagTxt)
    {
        this.tagTxt = tagTxt;
    }

    public void tagLost(TagLossEvent tagLossEvent)
    {
        tagTxt.setText("");
    }
    
}
